"use strict";
cc._RF.push(module, '51232MuRg1Etoh6eMoOYPIJ', 'config');
// Script/config.js

"use strict";

var config = {};

config.pokerCardType = {
    // spade : "spade",//黑桃
    // hearts : "hearts",//红桃
    // redslice : "redslice",//红方
    // blackberry : "blackberry",//黑梅
    spade: 1, //黑桃
    hearts: 2, //红桃
    redslice: 3, //红方
    blackberry: 4 //黑梅
};

config.ghostCardType = {
    bigG: "bigG", //大王
    smallG: "smallG" //小王


    //数组降序排列
};config.arrayDown = function (val1, val2) {
    return val2 - val1;
};
//数组升序排列
config.arrayUp = function (val1, val2) {
    return val1 - val2;
};
//截取数组的一部分
config.arraySub = function (index, count, arr) {
    var newarr = [];
    for (var i = index; i < count; i++) {
        newarr.push(arr[i]);
    }
    return newarr;
};

config.arraySub2 = function (index, count, arr) {
    var newarr = [];
    for (var i = index; i < count; i++) {
        newarr.push(arr[i]);
        newarr.push(arr[i]);
    }
    return newarr;
};

config.arraySub3 = function (index, count, arr) {
    var newarr = [];
    for (var i = index; i < count; i++) {
        newarr.push(arr[i]);
        newarr.push(arr[i]);
        newarr.push(arr[i]);
    }
    return newarr;
};

config.seatPos = {
    center: {
        pokerScale: 1, //0.5
        disBetween: 77, //45
        positionY: 250
    },
    left: {
        pokerScale: 0.4,
        disBetween: 25,
        positionY: 500
    },
    right: {
        pokerScale: 0.4,
        disBetween: 25,
        positionY: 500
    }

};

config.opratType = {
    callLoad: 1, //叫地主
    grabLoad: 2, //抢地主
    mustOutCard: 3 //自己必须出牌


    //牌型编号
};config.CardType = {
    Single: 1, //单张
    Pair: 2, //对子
    ThreeOfKind: 3, //三不带
    ThreeOfKindPlusOne: 4, //三带一
    ThreeOfKindPlusPair: 5, //三带二
    Straight: 6, //顺子
    StraightDouble: 7, //双顺  33 44 55
    StraightThree: 8, //三顺  333 444    飞机  [333 444 555 a b c/ aa bb cc]
    StraightThreePlusSingle: 9, //三顺+散牌 飞机带翅膀  333 444 5 6 / +一对
    StraightThreePlusPair: 10, //三顺+对   飞机带翅膀  333 444 66 77
    SoftBomb: 87, //软炸弹
    Bomb: 88, //炸弹
    LazarilloBomb: 89, //纯癞子炸弹
    DoubleKing: 99, //双王
    FourPlusOne: 11, //四带1, 四只带两只单牌
    FourPlusTwo: 12 //四带2, 四只带两对
};

module.exports = config;

cc._RF.pop();