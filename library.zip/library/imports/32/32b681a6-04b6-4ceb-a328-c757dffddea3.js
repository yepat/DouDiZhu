"use strict";
cc._RF.push(module, '32b68GmBLZM66Mox1ff/d6j', 'opratShowCardControl');
// Script/opratShowCardControl.js

"use strict";

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        labTxt: {
            default: null,
            type: cc.Label
        }
    },

    start: function start() {
        this.show(5, null);
    },
    show: function show(time, click) {
        this.time = time;
        this.click = click;

        this.labTxt.string = "明牌X" + time;

        this.schedule(function () {
            if (this.time > 2) {
                this.time -= 1;
                this.labTxt.string = "明牌X" + this.time;
            } else {
                this.labTxt.string = "明牌X2";
                this.node.destroy();
            }
        }, 1.0, this.time, 0);
    },
    btnClick: function btnClick() {
        console.log("点击了明牌按钮");
        if (this.click) {
            this.click();
        }
        this.node.destroy();
    }
});

cc._RF.pop();