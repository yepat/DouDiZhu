"use strict";
cc._RF.push(module, 'c56d3EULtVHAqVq6xWd2VvQ', 'opratDoubleControl');
// Script/opratDoubleControl.js

"use strict";

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        progressBar: {
            default: null,
            type: cc.ProgressBar
        }
    },

    start: function start() {
        // this.show(10,null);
    },
    show: function show(time, click) {
        this.time = time * 10;
        this.click = click;

        this.pross = 1.0;
        this.dt = 1 / this.time;

        this.schedule(function () {
            if (this.pross > 0) {
                this.pross -= this.dt;
                this.progressBar.getComponent(cc.ProgressBar).progress = this.pross;
            } else {
                this.progressBar.getComponent(cc.ProgressBar).progress = 0;
                this.node.destroy();
            }
        }, 0.1, this.time, 0.01);
    },
    btnClick: function btnClick() {
        console.log("点击了加倍按钮");
        if (this.click) {
            this.click();
        }
        this.node.destroy();
    }
});

cc._RF.pop();