"use strict";
cc._RF.push(module, '1393cipeeNFZbpX9aJxYpTG', 'GameTable');
// Script/GameTable.js

"use strict";

var PokerData = require("PokerData");
var PokerControl = require("PokerControl");
var config = require("config");

var CardUtil = require("CardUtil");
var PopCardUtil = require("PopCardUtil");

var opratOutCardControl = require("opratOutCardControl");

cc.Class({
    extends: cc.Component,

    properties: {
        pokerCard: {
            default: null,
            type: cc.Prefab
        },

        pokerLayer: {
            default: null,
            type: cc.Node
        },

        chupaiBtn: {
            default: null,
            type: cc.Node
        },

        buchuBtn: {
            default: null,
            type: cc.Node
        },
        canvas: cc.Node,
        opratOutCard: {
            default: null,
            type: cc.Prefab
        },

        tishi: {
            default: null,
            type: cc.Label
        }
    },

    // LIFE-CYCLE CALLBACKS:
    onLoad: function onLoad() {
        //初始化纸牌数据
        PokerData.load();
    },
    start: function start() {
        var self = this;

        this.tishi.enabled = false;

        self.touchBeganX = 0;
        self.leftX = 0;
        self.rightX = 0;
        self.upY = 0;
        self.downY = 0;
        self.isTouchbegan = false;
        //得到第三份数据
        var allPeoplePokerData = PokerData.getPartCardsData();
        var leftPokerData = allPeoplePokerData[0];
        var rightPokerData = allPeoplePokerData[1];
        var myPokerData = allPeoplePokerData[2];
        console.log(config.seatPos);

        //xx_test
        myPokerData = [];
        var myCardValue = [3, 5, 5, 5, 5, 6, 6, 6, 6, 9, 9, 9, 10, 10, 10, "J", "J", "J", "g", "G"];
        var myCardColor = [1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, "smallG", "bigG"];
        for (var i = 0; i < 20; i++) {
            var pokerDataItem = {
                showTxt: myCardValue[i],
                showType: myCardColor[i]
            };
            myPokerData.push(pokerDataItem);
        }
        myPokerData.sort(CardUtil.gradeDown);

        //-----
        // var source = [3,3,3,5,6,7,7,7,9,9,10,10,11,11,12,12,12];
        // var source = [];
        // for(var i=0;i<myCardValue.length;i++){
        //     source[i]=CardUtil.StringToNumber(myCardValue[i]);
        // }
        // console.log("sourcelength:"+source.length);

        // var sameValues = PopCardUtil.getSameCards(myCardValue);
        // PopCardUtil.setSameVulueCardCount(sameValues);

        // for(var k in sameValues){
        //     var d = sameValues[k];
        //     console.log("length_d:"+d.length+"  k:"+k);
        // }
        //-----


        var myPokerNode = [];
        var leftPokerNode = [];
        var rightPokerNode = [];
        var dispatchCard = [];
        var sceneWidth = cc.director.getWinSize().width;
        //将预制节点放置在界面上
        // var scene = cc.director.getScene();
        var scene = this.pokerLayer;

        for (var i = 0; i < myPokerData.length; i++) {
            var cardNode = cc.instantiate(this.pokerCard);
            cardNode.parent = scene;
            cardNode.scale = config.seatPos.center.pokerScale;
            var poker = cardNode.getComponent(PokerControl);
            myPokerData[i].canTouch = true;
            poker.showPoker(myPokerData[i]);
            myPokerNode.push(cardNode);
            this.neatenPoker(myPokerNode, config.seatPos.center, sceneWidth);
        }

        //最后一张牌设置为地主牌
        myPokerNode[myPokerNode.length - 1].getComponent(PokerControl).setCardDiZhu(true);

        // for(var i = 0;i < leftPokerData.length;i++){
        //     var cardNode = cc.instantiate(this.pokerCard);
        //     cardNode.parent = scene;
        //     cardNode.scale = config.seatPos.left.pokerScale;
        //     var poker = cardNode.getComponent(PokerControl);
        //     leftPokerData[i].canTouch = false;
        //     poker.showPoker(leftPokerData[i]);
        //     leftPokerNode.push(cardNode);
        //     this.neatenPoker(leftPokerNode,config.seatPos.left,sceneWidth/2, 50);
        // }

        // for(var i = 0;i < rightPokerData.length;i++){
        //     var cardNode = cc.instantiate(this.pokerCard);
        //     cardNode.parent = scene;
        //     cardNode.scale = config.seatPos.right.pokerScale;
        //     var poker = cardNode.getComponent(PokerControl);
        //     rightPokerData[i].canTouch = false;
        //     poker.showPoker(rightPokerData[i]);
        //     rightPokerNode.push(cardNode);
        //     this.neatenPoker(rightPokerNode,config.seatPos.right,sceneWidth/2, sceneWidth/2 + 50);
        // }

        this.myPokerData = myPokerData;
        this.myPokerNode = myPokerNode;
        this.dispatchCard = dispatchCard;

        this.sceneWidth = sceneWidth;
        this.scene = scene;

        this.registerEvent();
    },

    //理牌
    neatenPoker: function neatenPoker(pokerNode, seatPosParam, showWidth, startX) {
        if (pokerNode.length < 1) {
            return;
        }
        var pokerNum = pokerNode.length;
        var needWidth = (pokerNum - 1) * seatPosParam.disBetween + pokerNode[0].getComponent(PokerControl).node.width * seatPosParam.pokerScale;
        // console.log("needWidth:" + needWidth);
        showWidth = showWidth || cc.director.getWinSize().width;
        var startPosX = (showWidth - needWidth) / 2;
        startX = startX || startPosX;
        for (var i = 0; i < pokerNode.length; i++) {
            pokerNode[i].setPosition(startX + i * seatPosParam.disBetween + pokerNode[0].getComponent(PokerControl).node.width * seatPosParam.pokerScale * 0.5, seatPosParam.positionY);
        }
    },

    //出牌
    playCard: function playCard(pokerNode) {
        if (pokerNode.length < 1) {
            return;
        }
        var cardScale = 0.57;
        var disBetween = 40;
        var showCardWidth = (pokerNode.length - 1) * disBetween + pokerNode[0].getComponent(PokerControl).node.width * cardScale;
        // console.log("showCardWidth:"+showCardWidth);
        var sceneWidth = cc.director.getWinSize().width;
        var startX = (sceneWidth - showCardWidth) / 2;
        // console.log("startX:"+startX);
        //设置出去的牌的大小
        for (var i = 0; i < pokerNode.length; i++) {
            pokerNode[i].scale = cardScale;
            var posX = startX + i * disBetween + pokerNode[0].getComponent(PokerControl).node.width * cardScale * 0.5;
            // console.log("posX:"+posX);
            var poker = pokerNode[i].getComponent(PokerControl);
            poker.node.runAction(cc.moveTo(0.2, posX, 550));

            if (i == pokerNode.length - 1) {
                poker.setCardDiZhu(true);
            }
        }
    },

    //注册触摸事件
    registerEvent: function registerEvent() {
        var self = this;
        var myPokerNode = this.myPokerNode;

        this.canvas.on(cc.Node.EventType.TOUCH_START, function (event) {
            // console.log("touchStart");
            if (myPokerNode.length < 1) return false;
            var p = event.getLocation();
            // console.log(">>x:"+p.x+">>y:"+p.y);
            self.touchBeganX = p.x;
            self.leftX = 0;
            self.rightX = 10000;
            self.upY = 10000;
            self.downY = 0;
            self.isTouchbegan = true;
            self.setSelectCardByTouch(myPokerNode, p.x, p.y, self.isTouchbegan);

            if (self.isTouchbegan) {
                var x1 = myPokerNode[0].getPositionX();
                var x2 = myPokerNode[myPokerNode.length - 1].getPositionX();
                var py = myPokerNode[0].getPositionY();
                var psize = myPokerNode[0].getContentSize();
                var pwidth = psize.width;
                var pheight = psize.height;

                var disBetween = 10;

                self.leftX = x1 - pwidth / 2 - disBetween;
                self.rightX = x2 + pwidth / 2 + disBetween;
                self.upY = py + pheight / 2 + 40;
                self.downY = py - pheight / 2;

                console.log("self.leftX:" + self.leftX + "  self.rightX:" + self.rightX + " self.downY:" + self.downY + "  self.upY:" + self.upY);
                if (self.isTouchbegan && (p.y > self.upY || p.y < self.downY || p.x < self.leftX || p.x > self.rightX)) {
                    self.moveAllCardDown(myPokerNode);
                }
            }
        }, this.node);
        this.canvas.on(cc.Node.EventType.TOUCH_END, function (event) {
            // console.log("touchEnd");
            if (myPokerNode.length < 1) return;
            var p = event.getLocation();
            self.moveCard(myPokerNode);
        }, this.node);
        this.canvas.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            if (myPokerNode.length < 1) return;
            var p = event.getLocation();
            if (Math.abs(self.touchBeganX - p.x) > 40) {
                self.isTouchbegan = false;
                self.setSelectCardByTouch(myPokerNode, p.x, p.y, self.isTouchbegan);
            }
        }, this.node);
    },

    //移除触摸事件
    unregisterEvent: function unregisterEvent() {
        this.canvas.targetOff(this.node);
        console.log("off");
    },
    setSelectCardByTouch: function setSelectCardByTouch(myPokerNode, x, y, istouchbegan) {
        var touchStart = this.touchBeganX;
        var touchEnd = x;
        this.isTouchbegan = istouchbegan;

        if (this.touchBeganX > x) {
            touchStart = x;
            touchEnd = this.touchBeganX;
        }

        //如果起点跟终点距离小于5 则处理成起点等于终点
        if (touchEnd - touchStart < 5) {
            touchEnd = touchStart;
        }

        var selected = false; //选中状态

        for (var i = 0; i < myPokerNode.length; i++) {
            var pokerNode = myPokerNode[i];
            var posY = pokerNode.getPositionY();
            var size = pokerNode.getContentSize();
            var posX = pokerNode.getPositionX(); //+ size.width/2;

            var width = size.width;
            var height = size.height;

            var disBetween = config.seatPos.center.disBetween;

            var right = posX - width / 2 + disBetween;
            var left = posX - width / 2;
            var buttom = posY - height / 2;
            var up = posY + height / 2;
            //最后一张整张牌都可以点击
            if (i == myPokerNode.length - 1) {
                right = posX + width / 2;
            }
            // console.log("left:"+left+"  right:"+right+" buttom:"+buttom+" up:"+up);
            // console.log("posX:"+posX+" posY:"+posY+" sizeW:"+width+" sizeH:"+height);
            if (y >= buttom && y <= up && (left >= touchStart && left <= touchEnd || right >= touchStart && right <= touchEnd || touchStart >= left && touchStart <= right || touchEnd >= left && touchEnd <= right)) {
                pokerNode.getComponent(PokerControl).setChoosed(true);
            } else {
                // pokerNode:clearSelection();
            }
        }
    },
    moveCard: function moveCard(myPokerNode) {
        for (var i = 0; i < myPokerNode.length; i++) {
            var pokerNode = myPokerNode[i];
            pokerNode.getComponent(PokerControl).cardMove();
        }
    },
    moveAllCardDown: function moveAllCardDown(myPokerNode) {
        console.log("moveAllCardDown");
        for (var i = 0; i < myPokerNode.length; i++) {
            var pokerNode = myPokerNode[i];
            pokerNode.getComponent(PokerControl).cardMoveDown();
        }
    },
    onShow: function onShow() {
        console.log("onShow");
        this.tishi.enabled = false;
        this.onMyOutCard();
    },
    onHide: function onHide() {
        console.log("onHide");
        //智能提牌测试
        var myPokerNode = this.myPokerNode;
        var myPokerData = this.myPokerData;
        var topcards = CardUtil.getMyTopCards(myPokerNode, PokerControl);

        var mycards = [];
        for (var i = myPokerData.length - 1; i > -1; i--) {
            mycards.push(myPokerData[i].showTxt);
            console.log("xx" + myPokerData[i].showTxt);
        }

        var autocards = CardUtil.getCardsFromTopCards(mycards, topcards);
        if (autocards.length < 1) {} else {
            this.moveAllCardDown(myPokerNode); //先放下在提起
            CardUtil.AutoChooseLiftUpCard(myPokerNode, PokerControl, autocards);
        }
    },

    //轮到自己出牌
    onMyOutCard: function onMyOutCard() {
        var self = this;
        var dispatchCard = this.dispatchCard;
        var sceneWidth = this.sceneWidth;
        // var scene = this.scene;
        var scene = cc.director.getScene();

        var myPokerNode = this.myPokerNode;
        var myPokerData = this.myPokerData;

        //牌桌上已经有了出牌，清除掉
        if (dispatchCard.length > 0) {
            console.log("dispatchCard.length:" + dispatchCard.length);
            for (var i = 0; i < dispatchCard.length; i++) {
                dispatchCard[i].getComponent(PokerControl).node.removeFromParent();
            }
            dispatchCard = [];
        }

        var buchuFunc = function buchuFunc() {
            self.tishi.enabled = true;
            self.moveAllCardDown(myPokerNode);
        };
        var tishiNum = 0;
        var tishiFunc = function tishiFunc() {
            // var cards = ["3","3","3","7","7"];
            var cards = [3, 3, 3, 4, 4, 4, 5, 5, 5, 7, 8, 9]; //"3","3","3","3"
            var cardstype = CardUtil.get_topCard_type(cards);
            var myCards = [];
            console.log(cardstype);

            for (var i = myPokerData.length - 1; i > -1; i--) {
                var cardValue = CardUtil.StringToNumber(myPokerData[i].showTxt);
                myCards.push(cardValue);
            }

            var tishicards = CardUtil.get_cards_larger(cardstype, myCards);

            console.log("xxx:" + tishicards.length);
            console.log(tishicards);
            // cards = CardUtil.NumberToString(tishicards[tishiNum]);
            cards = tishicards[tishiNum];

            if (tishiNum < tishicards.length - 1) {
                tishiNum++;
            } else {
                tishiNum = 0;
            }

            // CardUtil.AutoChooseLiftUpCard(myPokerNode,PokerControl,cards);

            setTimeout(function () {
                //setInterval() 
                CardUtil.AutoChooseLiftUpCard(myPokerNode, PokerControl, cards);
            }, 500);
            self.moveAllCardDown(myPokerNode);
        };
        var chupaiFunc = function chupaiFunc() {
            console.log("点击了出牌");
            var topCards = [];
            //获取提起的牌直
            for (var i = myPokerData.length - 1; i > -1; i--) {
                if (myPokerData[i].isTopped) {
                    var cardValue = CardUtil.StringToNumber(myPokerData[i].showTxt);
                    topCards.push(cardValue);
                }
            }

            if (topCards.length >= 1) {
                var popCardsType = CardUtil.get_topCard_type(topCards);
                console.log(popCardsType);
                if (popCardsType.type == 0) {
                    console.log("提起的牌不合法");
                    return -1;
                }
            } else {
                console.log("没有牌提起");
                return 0;
            }

            for (var i = myPokerData.length - 1; i > -1; i--) {
                if (myPokerData[i].isTopped) {
                    //myPokerData[i].isChoosed
                    var isChoosedPoker = myPokerNode[i];
                    dispatchCard.unshift(isChoosedPoker);
                    myPokerData.splice(i, 1);
                    myPokerNode.splice(i, 1);
                }
            }
            self.dispatchCard = dispatchCard;
            //出牌
            self.playCard(dispatchCard);
            self.neatenPoker(myPokerNode, config.seatPos.center, sceneWidth);
            //最后一张牌设置为地主牌
            if (myPokerNode.length > 0) {
                myPokerNode[myPokerNode.length - 1].getComponent(PokerControl).setCardDiZhu(true);
            }
        };
        var opOutCard = cc.instantiate(this.opratOutCard);
        opOutCard.parent = scene;
        var opOutCardControl = opOutCard.getComponent(opratOutCardControl);
        opOutCardControl.show(20, buchuFunc, tishiFunc, chupaiFunc);
    }
});

cc._RF.pop();