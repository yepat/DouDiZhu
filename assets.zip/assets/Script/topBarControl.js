
var config = require("config");
var EventHelper = require("EventHelper");
var PlayerDetailModel = require("PlayerDetailModel");

cc.Class({
    extends: cc.Component,

    properties: {
        headImg : {
            default : null,
            type : cc.Sprite
        },
        playerName : {
            default : null,
            type : cc.Label
        },
        playerLevel : {
            default : null,
            type : cc.Label
        },
        playerLedou : {
            default : null,
            type : cc.Label
        },
        playerLeQuan : {
            default : null,
            type : cc.Label
        }
    },
    // onLoad () {},
    start () {
       var self = this;
        self.setHeadUrl();
        self.setNickName(PlayerDetailModel.getNickName());
        self.setLevel(PlayerDetailModel.getTitle());
        self.setLeDou(PlayerDetailModel.getCoin());
        self.setLuQuan(PlayerDetailModel.getCoupon());

        EventHelper.AddCustomEvent(config.MyNode,"RefreshDataResult",self.onRefreshDataResult,self);
    },
    onRefreshDataResult(event){
        console.log("刷新用户信息数据1111------");
        var self = this;
        var data = event.getUserData();
        console.log(data);

        var payload = data;
        // var model = app:getModel("PlayerDetailModel")
        //用户乐豆数
        if (payload.data && payload.data.coins){
            PlayerDetailModel.setCoin(payload.data.coins)
            self.setLeDou(PlayerDetailModel.getCoin());
        }
        //用户奖券数
        if (payload.data && payload.data.coupon){
            PlayerDetailModel.setCoupon(payload.data.coupon)
            self.setLuQuan(PlayerDetailModel.getCoupon());
        }
        //用户抽奖数
        if (payload.data && payload.data.lottery){
            PlayerDetailModel.setLottery(payload.data.lottery)
        }
        //未读邮件数
        if (payload.data && payload.data.mail_unread){
            PlayerDetailModel.setMailUnread(payload.data.mail_unread)
        }
        //0不可签到, 1可以签到
        if (payload.data && payload.data.checkin_undo){
            PlayerDetailModel.setCheckinUndo(payload.data.checkin_undo)
        }
        //可领奖的每日任务数
        if (payload.data && payload.data.task1_unaward){
            PlayerDetailModel.setTask1Unaward(payload.data.task1_unaward)
        }
        //可领奖的成长任务数
        if (payload.data && payload.data.task2_unaward){
            PlayerDetailModel.setTask2Unaward(payload.data.task2_unaward)
        }
        //充值奖励利率
        if (payload.data && payload.data.charge_rate){
            PlayerDetailModel.setChargeRate(payload.data.charge_rate)
        }
        //皮肤
        if (payload.data && payload.data.propDress){
            PlayerDetailModel.setPropDress(payload.data.propDress)
        }
        //道具
        if (payload.data && payload.data.propItems){
            PlayerDetailModel.setPropItems(payload.data.propItems)
        }
        // self.playerDetailController_:refreshUI()
    },
    setHeadUrl(){
        var self = this;
         //设置微信头像
         var imgUrl=config.wxInfo.avatarUrl;
         imgUrl = imgUrl + "?aa=aa.jpg";
         cc.loader.load(imgUrl, function(err, texture){
             self.headImg.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
         });
    },
    setNickName(name){
         //修改昵称
         this.playerName.string = name;
    },
    setLevel(lv){
        //修改等级
        this.playerLevel.string = lv;
    },
    setLeDou(number){
        //修改乐豆数
        if(number >= 10000000){
            number = Math.floor(number / 10000)
            this.playerLedou.string = ""+number+"万";
        }else{
            this.playerLedou.string = ""+number;
        }
        
    },
    setLuQuan(number){
        //修改乐券数
        if(number >= 10000000){
            number = Math.floor(number / 10000)
            this.playerLeQuan.string = ""+number+"万";
        }else{
            this.playerLeQuan.string = ""+number;
        }
    }
});
